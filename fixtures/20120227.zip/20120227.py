from cs1robots import *

#You can change map by modifying "maze1.wld" to other map name
load_world("maze1.wld")

################### DO NOT TOUCH ##############################
hubo = Robot(avenue=10,street=1,orientation = 'N')
ami = Robot(color="yellow",orientation = 'N')
###############################################################

